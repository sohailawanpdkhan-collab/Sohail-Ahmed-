# NexaChat (skeleton)

This is a ready-to-use Flutter project skeleton for *NexaChat* with a Black & Gold theme and Email+Password Firebase authentication UI.

## Important notes before building on Codemagic or locally

1. This repository intentionally **does not** include `android/` and `ios/` folders.
   - Codemagic workflow included (`codemagic.yaml`) runs `flutter create .` to generate these platform folders before building.
2. **Firebase setup required** for Email/Password authentication:
   - Create a Firebase project.
   - Add an Android app with your package name (e.g. `com.nexa.nexachat`) and download `google-services.json`.
   - Add `google-services.json` to `android/app/`.
   - For iOS, add the `GoogleService-Info.plist` to `ios/Runner/`.
   - Enable **Email/Password** sign-in in Firebase Console → Authentication.
3. Upload this repo to GitHub and connect to Codemagic. Use the provided `codemagic.yaml` workflow (YAML mode).
4. On Codemagic, ensure you add any necessary environment variables or code signing if building release.

## Files included
- `pubspec.yaml` — dependencies
- `lib/main.dart` — app with Black & Gold theme and Email/Password auth screens
- `assets/icon.png` — placeholder icon
- `codemagic.yaml` — Codemagic workflow to build debug APK
