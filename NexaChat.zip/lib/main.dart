import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';

// Note: This is a minimal functional skeleton to test Firebase connectivity.
// You'll still need to run flutter pub get and build in Codemagic.

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(NexaChatApp());
}

class NexaChatApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NexaChat (Debug)',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: _auth.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          return RoomsScreen();
        } else {
          return SignInScreen();
        }
      },
    );
  }
}

class SignInScreen extends StatelessWidget {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<void> _anonSignIn() async {
    await _auth.signInAnonymously();
  }

  Future<void> _googleSignIn() async {
    final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
    if (googleUser == null) return;
    final googleAuth = await googleUser.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );
    await _auth.signInWithCredential(credential);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('NexaChat — Sign in')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(onPressed: _anonSignIn, child: Text('Sign in Anonymously')),
            SizedBox(height: 12),
            ElevatedButton(onPressed: _googleSignIn, child: Text('Sign in with Google')),
          ],
        ),
      ),
    );
  }
}

class RoomsScreen extends StatelessWidget {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final CollectionReference rooms = FirebaseFirestore.instance.collection('rooms');

  Future<void> _createRoom(BuildContext context) async {
    final nameCtl = TextEditingController();
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Create room'),
        content: TextField(controller: nameCtl, decoration: InputDecoration(hintText: 'Room name')),
        actions: [
          TextButton(onPressed: ()=> Navigator.pop(context), child: Text('Cancel')),
          TextButton(onPressed: () async {
            final name = nameCtl.text.trim();
            if (name.isNotEmpty) {
              await rooms.add({'name': name, 'createdAt': FieldValue.serverTimestamp()});
            }
            Navigator.pop(context);
          }, child: Text('Create')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('NexaChat Rooms'),
        actions: [
          IconButton(icon: Icon(Icons.logout), onPressed: ()=> _auth.signOut()),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: rooms.orderBy('createdAt', descending: true).snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
          final docs = snapshot.data!.docs;
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (ctx, i) {
              final d = docs[i];
              return ListTile(
                title: Text(d['name'] ?? 'Room'),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(roomId: d.id, roomName: d['name']))),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: ()=> _createRoom(context),
        child: Icon(Icons.add),
      ),
    );
  }
}

class ChatScreen extends StatefulWidget {
  final String roomId;
  final String roomName;
  ChatScreen({required this.roomId, required this.roomName});
  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _ctl = TextEditingController();
  final user = FirebaseAuth.instance.currentUser;
  CollectionReference get msgs => FirebaseFirestore.instance.collection('rooms').doc(widget.roomId).collection('messages');

  Future<void> _send() async {
    final text = _ctl.text.trim();
    if (text.isEmpty) return;
    await msgs.add({
      'text': text,
      'senderId': user?.uid,
      'senderName': user?.displayName ?? 'User',
      'createdAt': FieldValue.serverTimestamp(),
    });
    _ctl.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.roomName)),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: msgs.orderBy('createdAt', descending: false).snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
                final docs = snapshot.data!.docs;
                return ListView.builder(
                  itemCount: docs.length,
                  itemBuilder: (ctx, i) {
                    final d = docs[i];
                    return ListTile(
                      title: Text(d['senderName'] ?? 'User'),
                      subtitle: Text(d['text'] ?? ''),
                    );
                  },
                );
              },
            ),
          ),
          SafeArea(child: Row(
            children: [
              Expanded(child: Padding(
                padding: const EdgeInsets.symmetric(horizontal:8.0),
                child: TextField(controller: _ctl),
              )),
              IconButton(icon: Icon(Icons.send), onPressed: _send)
            ],
          ))
        ],
      ),
    );
  }
}
